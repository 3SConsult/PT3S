.

Use SIR 3S Modeldata and SIR 3S Results in pure Python.

With pandas, geopandas, matplotlib and others.

For documentation, test, verification, analysis, reporting, prototyping, play.
